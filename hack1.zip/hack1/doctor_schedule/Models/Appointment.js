// models/Appointment.js
const mongoose = require('mongoose');

const AppointmentSchema = new mongoose.Schema({
  doctor: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  patient: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  slotStart: { type: Date, required: true },
  slotEnd: { type: Date, required: true },
  status: { type: String, enum: ['booked','cancelled','completed'], default: 'booked' },
  createdAt: { type: Date, default: Date.now }
});

AppointmentSchema.index({ doctor: 1, slotStart: 1 }, { unique: true }); // prevent double-book

module.exports = mongoose.model('Appointment', AppointmentSchema);
