// models/Schedule.js
const mongoose = require('mongoose');

/**
 Schedule model:
 - doctor: reference to User (role doctor)
 - slots: weekly template array of objects:
    { day: 0..6 (Sun=0), start: "HH:MM", end: "HH:MM", slotDuration: minutes }
 - updatedAt
*/
const WeeklySlotSchema = new mongoose.Schema({
  day: { type: Number, required: true }, // 0..6 (Sun = 0)
  start: { type: String, required: true }, // "09:00"
  end: { type: String, required: true },   // "17:00"
  slotDuration: { type: Number, required: true } // minutes
}, { _id: false });

const ScheduleSchema = new mongoose.Schema({
  doctor: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
  weekly: [WeeklySlotSchema],
  updatedAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Schedule', ScheduleSchema);
