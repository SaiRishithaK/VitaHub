// routes/appointments.js
const express = require('express');
const Appointment = require('../Models/Appointment');
const Schedule = require('../Models/Schedule');
const auth = require('../Middleware/auth');

const router = express.Router();

/**
 * POST /api/appointments
 * Body: { doctorId, slotStartISO }   // slotStartISO is ISO string, e.g. "2025-11-22T10:00:00"
 * Auth: patient (or any logged user)
 */
router.post('/', auth, async (req, res) => {
  try {
    const { doctorId, slotStart } = req.body;
    if (!doctorId || !slotStart) return res.status(400).json({ message: 'Missing doctorId or slotStart' });

    const slotStartDate = new Date(slotStart);
    if (isNaN(slotStartDate)) return res.status(400).json({ message: 'Invalid date' });

    // check if doctor has schedule that contains this slot (basic validation)
    const schedule = await Schedule.findOne({ doctor: doctorId });
    if (!schedule) return res.status(400).json({ message: 'Doctor has no schedule' });

    // Determine which weekly config this slot would match
    const day = slotStartDate.getDay();
    const timeStr = slotStartDate.toTimeString().slice(0,5); // "HH:MM"
    // We'll try to find a cfg where slotStart aligns with start + n * slotDuration
    const configs = schedule.weekly.filter(w => w.day === day);
    if (configs.length === 0) return res.status(400).json({ message: 'No availability on this day' });

    let matchedConfig = null;
    for (const cfg of configs) {
      const [sh, sm] = cfg.start.split(':').map(Number);
      const [eh, em] = cfg.end.split(':').map(Number);
      const slotDur = Number(cfg.slotDuration);

      // build start-of-day and compare differences in minutes
      const base = new Date(slotStartDate);
      base.setHours(sh, sm, 0, 0);
      const end = new Date(slotStartDate);
      end.setHours(eh, em, 0, 0);

      if (slotStartDate < base || slotStartDate.getTime() + slotDur*60000 > end.getTime()) continue;

      // check alignment
      const diffMin = Math.round((slotStartDate.getTime() - base.getTime()) / 60000);
      if (diffMin % slotDur === 0) {
        matchedConfig = cfg;
        break;
      }
    }

    if (!matchedConfig) {
      return res.status(400).json({ message: 'Slot not valid according to schedule' });
    }

    const slotEndDate = new Date(slotStartDate.getTime() + matchedConfig.slotDuration*60000);

    // create appointment: unique index on doctor+slotStart prevents duplicates
    try {
      const appt = await Appointment.create({
        doctor: doctorId,
        patient: req.user._id,
        slotStart: slotStartDate,
        slotEnd: slotEndDate,
        status: 'booked'
      });

      return res.json({ message: 'Booked', appointment: appt });
    } catch (err) {
      // if unique index error -> already booked
      if (err.code === 11000) {
        return res.status(400).json({ message: 'Slot already booked' });
      }
      throw err;
    }

  } catch (err) {
    console.error('Booking error', err);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * GET /api/appointments/my
 * Auth: user
 * Returns appointments for logged user (patient) or doctor (as doctor)
 */
router.get('/my', auth, async (req, res) => {
  try {
    const q = (req.user.role === 'doctor') ?
      { doctor: req.user._id } :
      { patient: req.user._id };

    const appts = await Appointment.find(q).populate('doctor', 'name email').populate('patient', 'name email').sort({ slotStart: 1 });
    res.json({ appointments: appts });
  } catch (err) {
    console.error('My appts error', err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
