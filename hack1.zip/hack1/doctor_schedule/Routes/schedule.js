// routes/schedule.js
const express = require('express');
const Schedule = require('../Models/Schedule');
const Appointment = require('../Models/Appointment');
const auth = require('../Middleware/auth');

const router = express.Router();

/**
 * POST /api/schedule
 * Body: { weekly: [{day:0..6, start:"HH:MM", end:"HH:MM", slotDuration:30}, ...] }
 * Auth: doctor
 * Create or update doctor's weekly schedule
 */
router.post('/', auth, async (req, res) => {
  try {
    if (req.user.role !== 'doctor') return res.status(403).json({ message: 'Only doctors can set schedule' });
    const weekly = req.body.weekly || [];
    // Validate basic
    if (!Array.isArray(weekly)) return res.status(400).json({ message: 'Invalid weekly format' });

    // Upsert schedule
    let schedule = await Schedule.findOne({ doctor: req.user._id });
    if (!schedule) {
      schedule = await Schedule.create({ doctor: req.user._id, weekly, updatedAt: new Date() });
    } else {
      schedule.weekly = weekly;
      schedule.updatedAt = new Date();
      await schedule.save();
    }
    res.json({ message: 'Schedule saved', schedule });
  } catch (err) {
    console.error('Save schedule error', err);
    res.status(500).json({ message: 'Server error' });
  }
});

/**
 * GET /api/schedule/:doctorId?startDate=YYYY-MM-DD
 * Returns array of slots for 7 days starting from startDate (inclusive)
 * Each slot: { start: ISODate, end: ISODate, isBooked: boolean }
 * If startDate not provided, uses today.
 */
router.get('/:doctorId', async (req, res) => {
  try {
    const doctorId = req.params.doctorId;
    const startDateStr = req.query.startDate; // yyyy-mm-dd
    const startDate = startDateStr ? new Date(startDateStr + 'T00:00:00') : (new Date());
    // Normalize to start of day local time
    startDate.setHours(0,0,0,0);

    const schedule = await Schedule.findOne({ doctor: doctorId });
    if (!schedule) return res.json({ slots: [] });

    // Helper: parse "HH:MM" + a date -> Date object in local timezone
    function combineDateTime(dateObj, hm) {
      const [hh, mm] = hm.split(':').map(Number);
      const d = new Date(dateObj);
      d.setHours(hh, mm, 0, 0);
      return d;
    }

    // get existing appointments for doctor in the window
    const dayMs = 24*60*60*1000;
    const endWindow = new Date(startDate.getTime() + 6*dayMs + (24*60*60*1000 - 1)); // inclusive week
    const existingAppts = await Appointment.find({
      doctor: doctorId,
      slotStart: { $gte: startDate, $lte: endWindow }
    });

    // Build slots for 7 days
    const slots = [];
    for (let i = 0; i < 7; i++) {
      const dayDate = new Date(startDate.getTime() + i * dayMs);
      const dayOfWeek = dayDate.getDay(); // 0..6

      // find weekly configs matching dayOfWeek
      const configs = schedule.weekly.filter(w => w.day === dayOfWeek);
      for (const cfg of configs) {
        // Create slots from cfg.start to cfg.end with duration cfg.slotDuration
        const slotDuration = Number(cfg.slotDuration) || 30;
        let cur = combineDateTime(dayDate, cfg.start);
        const end = combineDateTime(dayDate, cfg.end);

        // If start >= end skip
        if (cur >= end) continue;

        while (cur.getTime() + slotDuration*60000 <= end.getTime() + 0) {
          const slotStart = new Date(cur);
          const slotEnd = new Date(cur.getTime() + slotDuration*60000);

          // check if any appointment occupies slotStart (existingAppts)
          const conflict = existingAppts.some(a => {
            return a.slotStart.getTime() === slotStart.getTime();
          });

          slots.push({
            start: slotStart,
            end: slotEnd,
            isBooked: !!conflict
          });

          // next
          cur = new Date(cur.getTime() + slotDuration*60000);
        }
      }
    }

    // sort slots by start time
    slots.sort((a,b) => a.start - b.start);

    res.json({ slots });
  } catch (err) {
    console.error('Get schedule slots error', err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
