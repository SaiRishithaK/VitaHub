// public/app.js
// small auth helpers used by index.html and other pages (global)
async function apiPost(url, body) {
  const res = await fetch(url, {
    method:'POST',
    headers: {'Content-Type':'application/json', ...(localStorage.getItem('token') ? {'Authorization':'Bearer '+localStorage.getItem('token')} : {}) },
    body: JSON.stringify(body)
  });
  return res;
}

// signup
document.getElementById('signupBtn')?.addEventListener('click', async () => {
  const name = document.getElementById('su_name').value;
  const email = document.getElementById('su_email').value;
  const password = document.getElementById('su_password').value;
  const role = document.getElementById('su_role').value;
  if (!name||!email||!password) return alert('Fill fields');
  const r = await apiPost('/api/auth/signup', { name, email, password, role });
  const j = await r.json();
  if (r.ok) {
    localStorage.setItem('token', j.token);
    localStorage.setItem('me', JSON.stringify(j.user));
    updateMe();
    alert('Signed up');
  } else {
    alert(j.message || 'Error');
  }
});

// login
document.getElementById('loginBtn')?.addEventListener('click', async () => {
  const email = document.getElementById('li_email').value;
  const password = document.getElementById('li_password').value;
  if (!email||!password) return alert('Fill fields');
  const r = await apiPost('/api/auth/login', { email, password });
  const j = await r.json();
  if (r.ok) {
    localStorage.setItem('token', j.token);
    localStorage.setItem('me', JSON.stringify(j.user));
    updateMe();
    alert('Logged in');
  } else {
    alert(j.message || 'Login failed');
  }
});

document.getElementById('logoutBtn')?.addEventListener('click', () => {
  localStorage.removeItem('token');
  localStorage.removeItem('me');
  updateMe();
});

function updateMe() {
  const me = JSON.parse(localStorage.getItem('me') || 'null');
  window.__me = me;
  const pre = document.getElementById('me');
  if (pre) pre.innerText = me ? JSON.stringify(me, null, 2) : 'Not logged';
}

updateMe();
